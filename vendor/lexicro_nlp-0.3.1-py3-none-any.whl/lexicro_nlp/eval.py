"""Evaluation harness for the `/analyze` output.

Reports, per the Phase 2 design doc:
  * UPOS accuracy
  * UFeats micro-F1 over (feature=value) pairs, plus per-feature P/R/F1
  * full-bundle exact match (FEATS set identical)
  * full-tag exact match (UPOS + FEATS)
  * lemma accuracy
  * "all correct" token rate (UPOS + FEATS + lemma)

Every metric is also sliced into in-lexicon vs OOV. The aggregate number is
flattered by easy lexicon tokens; the OOV slice is the real quality signal.
`known_forms` is the lexicon membership set — training vocabulary pre-RoLEX,
the RoLEX form inventory once licensed.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .data import Word


@dataclass
class Metrics:
    n: int = 0
    upos_correct: int = 0
    bundle_exact: int = 0
    fulltag_exact: int = 0
    lemma_correct: int = 0
    all_correct: int = 0
    feat_tp: int = 0
    feat_fp: int = 0
    feat_fn: int = 0
    per_feat: dict = field(default_factory=dict)  # feature -> [tp, fp, fn]

    @staticmethod
    def _prf(tp: int, fp: int, fn: int) -> tuple[float, float, float]:
        p = tp / (tp + fp) if tp + fp else 0.0
        r = tp / (tp + fn) if tp + fn else 0.0
        f = 2 * p * r / (p + r) if p + r else 0.0
        return p, r, f

    def ratio(self, num: int) -> float:
        return num / self.n if self.n else 0.0

    def feats_microf1(self) -> tuple[float, float, float]:
        return self._prf(self.feat_tp, self.feat_fp, self.feat_fn)

    def per_feat_f1(self) -> dict[str, tuple[float, float, float]]:
        return {k: self._prf(*v) for k, v in sorted(self.per_feat.items())}


def _score_one(m: Metrics, gold: Word, pred: Word) -> None:
    m.n += 1
    if gold.upos == pred.upos:
        m.upos_correct += 1

    bundle_ok = gold.feats == pred.feats
    if bundle_ok:
        m.bundle_exact += 1
    fulltag_ok = bundle_ok and gold.upos == pred.upos
    if fulltag_ok:
        m.fulltag_exact += 1

    lemma_ok = gold.lemma == pred.lemma
    if lemma_ok:
        m.lemma_correct += 1
    if fulltag_ok and lemma_ok:
        m.all_correct += 1

    # UFeats micro / per-feature: value must match for a true positive.
    for key in set(gold.feats) | set(pred.feats):
        gv = gold.feats.get(key)
        pv = pred.feats.get(key)
        slot = m.per_feat.setdefault(key, [0, 0, 0])
        if gv is not None and gv == pv:
            slot[0] += 1
            m.feat_tp += 1
        else:
            if pv is not None:  # predicted a value that is wrong or spurious
                slot[1] += 1
                m.feat_fp += 1
            if gv is not None:  # gold value missed or mis-valued
                slot[2] += 1
                m.feat_fn += 1


class Scorer:
    """Accumulates overall + in-lexicon + OOV metrics over aligned tokens."""

    def __init__(self, known_forms: set[str], casefold_known: bool = True):
        self.casefold_known = casefold_known
        self.known = (
            {f.casefold() for f in known_forms} if casefold_known else set(known_forms)
        )
        self.overall = Metrics()
        self.in_lexicon = Metrics()
        self.oov = Metrics()

    def _is_known(self, form: str) -> bool:
        key = form.casefold() if self.casefold_known else form
        return key in self.known

    def update(self, gold: Word, pred: Word) -> None:
        _score_one(self.overall, gold, pred)
        _score_one(self.in_lexicon if self._is_known(gold.form) else self.oov, gold, pred)

    def update_sentence(self, gold: list[Word], pred: list[Word]) -> None:
        if len(gold) != len(pred):
            raise ValueError(
                f"token count mismatch: gold={len(gold)} pred={len(pred)}"
            )
        for g, p in zip(gold, pred):
            if g.form != p.form:
                raise ValueError(f"form mismatch: gold={g.form!r} pred={p.form!r}")
            self.update(g, p)


def _fmt_block(name: str, m: Metrics) -> str:
    if m.n == 0:
        return f"{name:<12} (no tokens)"
    fp, fr, ff = m.feats_microf1()
    return (
        f"{name:<12} n={m.n:>6}  "
        f"UPOS={m.ratio(m.upos_correct):6.2%}  "
        f"FEATS-F1={ff:6.2%}  "
        f"bundle={m.ratio(m.bundle_exact):6.2%}  "
        f"tag={m.ratio(m.fulltag_exact):6.2%}  "
        f"lemma={m.ratio(m.lemma_correct):6.2%}  "
        f"all={m.ratio(m.all_correct):6.2%}"
    )


def format_report(scorer: Scorer, per_feature: bool = True) -> str:
    lines = [
        _fmt_block("OVERALL", scorer.overall),
        _fmt_block("in-lexicon", scorer.in_lexicon),
        _fmt_block("OOV", scorer.oov),
    ]
    if per_feature and scorer.overall.per_feat:
        lines.append("")
        lines.append("per-feature F1 (overall):")
        for feat, (p, r, f) in scorer.overall.per_feat_f1().items():
            lines.append(f"  {feat:<12} P={p:6.2%}  R={r:6.2%}  F1={f:6.2%}")
    return "\n".join(lines)
