"""Baseline `/analyze` model: one encoder, two heads.

    sentence -> BERT (one forward pass) -> first-subword vector per word
                                            |-> tag head    (UPOS+FEATS composite)
                                            |-> lemma head  (edit script)

Two design points from the Phase 2 doc, both load-bearing:

* **First-subword pooling.** BERT tokenises into subwords; we predict on the
  first subword of each word and ignore the rest (label -100). Everything
  downstream is word-level, which is what the API contract promises.

* **Constrained decoding lives at inference only.** The heads are trained
  unconstrained. `predict()` optionally takes a per-token boolean mask of
  allowed tags; disallowed logits go to -inf before the argmax. Because the
  constraint only ever removes options, applying it at inference is strictly
  beneficial and keeps train/serve decoupled. Pre-RoLEX you pass no mask and
  nothing changes; post-RoLEX you pass the lexicon's candidate set and get
  lexicon-grade output for free. That is the whole hybrid seam, in one argument.
"""

from __future__ import annotations

import torch
import torch.nn as nn
from transformers import AutoConfig, AutoModel

IGNORE = -100


class MorphTagger(nn.Module):
    def __init__(
        self,
        encoder_name: str,
        n_tags: int,
        n_scripts: int,
        dropout: float = 0.1,
        lemma_loss_weight: float = 1.0,
        _config_only: bool = False,   # tests: build from config, skip pretrained download
    ):
        super().__init__()
        if _config_only:
            cfg = AutoConfig.from_pretrained(encoder_name) if isinstance(encoder_name, str) else encoder_name
            self.encoder = AutoModel.from_config(cfg)
        else:
            self.encoder = AutoModel.from_pretrained(encoder_name)
        hidden = self.encoder.config.hidden_size

        self.dropout = nn.Dropout(dropout)
        self.tag_head = nn.Linear(hidden, n_tags)
        # The lemma script depends on the morphology (same form, different tag ->
        # different lemma), so the lemma head sees the tag distribution as well as
        # the contextual vector. This is the cheap version of "conditioned on the
        # predicted tag" -- differentiable, and no decoding order to enforce.
        self.lemma_head = nn.Linear(hidden + n_tags, n_scripts)

        self.lemma_loss_weight = lemma_loss_weight
        self.loss_fn = nn.CrossEntropyLoss(ignore_index=IGNORE)

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
        tag_labels: torch.Tensor | None = None,
        script_labels: torch.Tensor | None = None,
    ):
        h = self.encoder(input_ids=input_ids, attention_mask=attention_mask).last_hidden_state
        h = self.dropout(h)

        tag_logits = self.tag_head(h)
        # Straight-through-ish: feed the tag distribution (not a hard argmax) so
        # gradients flow into the tag head from the lemma loss too.
        lemma_in = torch.cat([h, tag_logits.softmax(-1)], dim=-1)
        script_logits = self.lemma_head(lemma_in)

        loss = None
        if tag_labels is not None and script_labels is not None:
            tag_loss = self.loss_fn(tag_logits.view(-1, tag_logits.size(-1)), tag_labels.view(-1))
            lemma_loss = self.loss_fn(script_logits.view(-1, script_logits.size(-1)), script_labels.view(-1))
            loss = tag_loss + self.lemma_loss_weight * lemma_loss

        return {
            "loss": loss,
            "tag_logits": tag_logits,
            "script_logits": script_logits,
        }

    @torch.no_grad()
    def predict(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
        allowed_tags: torch.Tensor | None = None,
    ):
        """Decode tag + lemma-script ids.

        `allowed_tags`: optional bool tensor [batch, seq, n_tags]. False entries
        are masked to -inf before the argmax. This is the RoLEX constraint hook;
        pass None pre-licence and the model decodes unconstrained.
        """
        out = self.forward(input_ids, attention_mask)
        tag_logits = out["tag_logits"]

        if allowed_tags is not None:
            # A token with no allowed tag (OOV) keeps its unconstrained logits --
            # never mask a row to all -inf, which would make the argmax arbitrary.
            has_candidates = allowed_tags.any(dim=-1, keepdim=True)
            mask = allowed_tags | ~has_candidates
            tag_logits = tag_logits.masked_fill(~mask, float("-inf"))

        return tag_logits.argmax(-1), out["script_logits"].argmax(-1)
