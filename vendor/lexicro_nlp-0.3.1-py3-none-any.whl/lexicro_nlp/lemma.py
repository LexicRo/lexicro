"""Edit-script lemmatisation.

An edit script is a deterministic, reversible form->lemma transformation. It
factors the shared prefix and suffix and stores only the differing middle:

    apply(form) = form[:lcp] + insert + form[-lcs:]

This is what collapses RoLEX's ~330k (form, lemma) pairs into a few hundred to
a few thousand distinct scripts, which is what makes the OOV lemma head a
tractable classification problem rather than open-ended char-level generation.
It is also deterministic, which the API's stability contract requires.

Casing: `lower=True` casefolds the form before transforming, which is right for
the overwhelmingly-lowercase Romanian lemma inventory. `derive_best` picks per
pair whichever of {lower, literal} round-trips with the smallest `insert`, so
proper nouns that keep their case (România, București) fall back to the literal
script automatically. Every script produced is guaranteed to round-trip.
"""

from __future__ import annotations

from dataclasses import dataclass


def _common_prefix_len(a: str, b: str) -> int:
    n = min(len(a), len(b))
    i = 0
    while i < n and a[i] == b[i]:
        i += 1
    return i


def _common_suffix_len(a: str, b: str, cap: int) -> int:
    n = min(len(a), len(b), cap)
    i = 0
    while i < n and a[-1 - i] == b[-1 - i]:
        i += 1
    return i


@dataclass(frozen=True)
class EditScript:
    lcp: int      # form-prefix chars to keep
    lcs: int      # form-suffix chars to keep
    insert: str   # lemma middle spliced between them
    lower: bool   # casefold the form before applying

    def apply(self, form: str) -> str:
        f = form.casefold() if self.lower else form
        keep_suffix = f[len(f) - self.lcs:] if self.lcs else ""
        return f[: self.lcp] + self.insert + keep_suffix

    def encode(self) -> str:
        """Compact string form, usable directly as a classifier label."""
        return f"{int(self.lower)}|{self.lcp}|{self.lcs}|{self.insert}"

    @classmethod
    def decode(cls, s: str) -> "EditScript":
        low, lcp, lcs, insert = s.split("|", 3)
        return cls(int(lcp), int(lcs), insert, bool(int(low)))


def derive(form: str, lemma: str, lower: bool = True) -> EditScript:
    """Derive an edit script for a single (form, lemma) pair.

    With `lower=False` the script is literal and always round-trips. With
    `lower=True` it round-trips whenever the lemma's casing matches the
    casefolded form outside the `insert` region (the common case).
    """
    f = form.casefold() if lower else form
    p = _common_prefix_len(f, lemma)
    cap = min(len(f) - p, len(lemma) - p)  # keep prefix/suffix regions disjoint
    s = _common_suffix_len(f, lemma, cap)
    insert = lemma[p: len(lemma) - s] if s else lemma[p:]
    return EditScript(p, s, insert, lower)


def derive_best(form: str, lemma: str) -> EditScript:
    """Pick the round-tripping script with the smallest `insert`.

    Prefers the casefolded script (better sharing across the lexicon) but falls
    back to the literal script for case-preserving lemmas. The literal script
    always round-trips, so a valid result is guaranteed.
    """
    candidates = [derive(form, lemma, lower=True), derive(form, lemma, lower=False)]
    valid = [c for c in candidates if c.apply(form) == lemma]
    return min(valid, key=lambda c: len(c.insert))
