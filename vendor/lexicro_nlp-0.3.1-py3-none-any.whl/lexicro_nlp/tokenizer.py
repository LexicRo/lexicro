"""Raw text -> sentences of word tokens, matching the RRT convention.

Everything upstream of this consumed pre-tokenised CoNLL-U. Production gets a
string, so this is the missing front end.

The interesting part is Romanian clitics. RRT contains *no* multiword-token
ranges; it pre-splits clitics and keeps the hyphen attached to the elided side:

    "s-a dus"    -> ["s-", "a", "dus"]
    "într-o casă" -> ["într-", "o", "casă"]
    "spune-i"     -> ["spune", "-i"]

The hyphen stays with whichever side was elided, and that side is not
predictable from the punctuation alone. But those hyphenated fragments (`s-`,
`într-`, `-i`, `-l`) are themselves entries in the MULTEXT-East lexicon -- so
instead of hand-coding Romanian clitic rules, we *ask the lexicon* which split
is real. Data we already have, doing work we would otherwise guess at.

Without a lexicon the tokeniser still runs; it just leaves hyphenated words
intact, which is the safe failure (a known word wrongly joined, rather than a
real word wrongly cut in half).
"""

from __future__ import annotations

import re

# A "word" is a run of letters (incl. Romanian diacritics), digits, apostrophes
# and internal hyphens. Everything else that is not whitespace is punctuation.
_TOKEN_RE = re.compile(
    r"""
    (?P<word>[\w'’\-]+)         # word-ish run (unicode-aware \w)
    | (?P<punct>[^\w\s])        # any single non-word, non-space char
    """,
    re.UNICODE | re.VERBOSE,
)

# Sentence end: . ! ? … possibly followed by closing quotes/brackets, then space
# and something that starts a new sentence.
_SENT_END = re.compile(r'(?<=[.!?…])["”»\')\]]*\s+(?=["“«\'(\[]*\w)', re.UNICODE)

# Abbreviations that end in a period but do not end a sentence.
_ABBREV = {
    "dl", "dna", "dnei", "dlui", "d-l", "d-na", "nr", "art", "alin", "lit",
    "pct", "cf", "etc", "ex", "vol", "pag", "p", "ed", "str", "bd", "sec",
    "prof", "dr", "ing", "av", "gen", "col", "lt", "mr", "cap", "fig",
}


def split_sentences(text: str) -> list[str]:
    """Split text into sentences. Deliberately simple; abbreviation-aware."""
    text = text.strip()
    if not text:
        return []

    parts: list[str] = []
    start = 0
    for m in _SENT_END.finditer(text):
        end = m.start()
        chunk = text[start:end].strip()
        if not chunk:
            continue
        # Do not break after a known abbreviation ("nr. 5", "art. 3").
        last = re.search(r"([\w\-]+)\.$", chunk)
        if last and last.group(1).casefold() in _ABBREV:
            continue
        parts.append(chunk)
        start = m.end()
    tail = text[start:].strip()
    if tail:
        parts.append(tail)
    return parts


def _split_hyphenated(word: str, known) -> list[str]:
    """Split a hyphenated word into clitic fragments, guided by the lexicon.

    `known` is a callable form -> bool. For each hyphen, we test the two RRT
    conventions -- hyphen kept on the left fragment, or on the right -- and take
    whichever the lexicon recognises. If neither is recognised, we leave the
    word whole: joining a real word is recoverable, cutting one in half is not.
    """
    if "-" not in word or known is None:
        return [word]
    # Never split a leading/trailing hyphen off on its own.
    core = word.strip("-")
    if not core or "-" not in core:
        return [word]

    for i, ch in enumerate(word):
        if ch != "-" or i == 0 or i == len(word) - 1:
            continue
        left_h, right = word[: i + 1], word[i + 1 :]      # "s-" + "a"
        left, right_h = word[:i], word[i:]                # "spune" + "-i"

        if known(left_h) and known(right):
            return [left_h] + _split_hyphenated(right, known)
        if known(left) and known(right_h):
            return [left] + _split_hyphenated(right_h, known)

    return [word]


def tokenize_sentence(sentence: str, known=None) -> list[str]:
    """Tokenise one sentence into words + punctuation."""
    tokens: list[str] = []
    for m in _TOKEN_RE.finditer(sentence):
        if m.group("punct"):
            tokens.append(m.group("punct"))
            continue
        word = m.group("word")
        # A bare hyphen (dash used as punctuation) is punctuation, not a word.
        if set(word) <= {"-"}:
            tokens.append(word)
            continue
        tokens.extend(_split_hyphenated(word, known))
    return tokens


def tokenize(text: str, known=None) -> list[list[str]]:
    """Raw text -> list of sentences, each a list of tokens."""
    return [
        toks
        for s in split_sentences(text)
        if (toks := tokenize_sentence(s, known))
    ]
