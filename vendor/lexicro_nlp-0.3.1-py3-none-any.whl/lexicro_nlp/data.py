"""CoNLL-U loading, normalised to the fields Phase 2 actually tags.

Two structural details the loader gets right, because both are silent-error
sources otherwise:

* Multiword-token ranges (`2-3  într-o  _ ...`) are skipped. We tag the
  syntactic words (`2 într`, `3 o`), not the surface span. In the `conllu`
  library these rows carry a tuple id `(2, '-', 3)`.
* Enhanced-dependency empty nodes (`5.1`) carry a tuple id `(5, '.', 1)` and
  are skipped for the same reason.

Only rows with an integer id survive.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Iterator

from conllu import parse_incr


@dataclass(frozen=True)
class Word:
    """One syntactic word: exactly the fields the tagger predicts."""

    form: str
    lemma: str
    upos: str
    feats: dict          # {} when the FEATS column is `_`
    source: str = ""     # originating treebank, kept for ablation slicing


def _feats_to_dict(feats) -> dict:
    # conllu parses FEATS into a dict, or None when the column is `_`.
    return dict(feats) if feats else {}


def _lemma_or_form(tok) -> str:
    lemma = tok["lemma"]
    # `_` in the lemma column means "unspecified"; fall back to the surface
    # form so downstream lemma metrics/edit-scripts have a defined target.
    if lemma is None or lemma == "_":
        return tok["form"]
    return lemma


def iter_sentences(path: str | Path, source: str = "") -> Iterator[list[Word]]:
    """Yield one `list[Word]` per sentence from a `.conllu` file."""
    path = Path(path)
    with path.open("r", encoding="utf-8") as fh:
        for token_list in parse_incr(fh):
            words: list[Word] = []
            for tok in token_list:
                if not isinstance(tok["id"], int):
                    continue  # MWT range or empty node
                words.append(
                    Word(
                        form=tok["form"],
                        lemma=_lemma_or_form(tok),
                        upos=tok["upos"],
                        feats=_feats_to_dict(tok["feats"]),
                        source=source,
                    )
                )
            if words:
                yield words


def load_pool(treebank_files: dict[str, str | Path]) -> list[list[Word]]:
    """Concatenate several treebanks, tagging each Word with its source.

    `treebank_files` maps a source label to a single `.conllu` split file, e.g.
    `{"RRT": ".../ro_rrt-ud-train.conllu", "Nonstandard": ".../ro_nonstandard-ud-train.conllu"}`.
    """
    pool: list[list[Word]] = []
    for name, path in treebank_files.items():
        pool.extend(iter_sentences(path, source=name))
    return pool


def build_vocab(sentences: Iterable[list[Word]], casefold: bool = True) -> set[str]:
    """Surface-form vocabulary — the pre-RoLEX proxy for `known_forms`.

    Swap this out for the RoLEX form inventory once the licence lands; the
    scorer's OOV slice will then reflect true lexicon coverage.
    """
    vocab: set[str] = set()
    for sent in sentences:
        for w in sent:
            vocab.add(w.form.casefold() if casefold else w.form)
    return vocab


def find_conllu(treebank_dir: str | Path, split: str) -> Path | None:
    """Resolve `*-ud-<split>.conllu` inside a cloned UD treebank directory."""
    treebank_dir = Path(treebank_dir)
    matches = sorted(treebank_dir.glob(f"*-ud-{split}.conllu"))
    return matches[0] if matches else None
