"""Turning `list[Word]` into model tensors.

The one genuinely error-prone step is **first-subword alignment**. BERT splits a
word into subwords; exactly one of them (the first) carries the label, the rest
get IGNORE (-100) so they contribute no loss. Get this wrong and the model
silently trains on garbage while the loss still looks plausible -- hence the
explicit tests.

Words that the tokenizer maps to *zero* subwords (rare, but real: some control
characters and stray combining marks) would silently shift every subsequent
label by one. We detect that case and keep the alignment honest by tracking
word_ids, never by assuming a 1:1 walk.
"""

from __future__ import annotations

from dataclasses import dataclass

import torch

from .data import Word
from .labels import composite_tag
from .lemma import derive_best

IGNORE = -100


class ScriptVocab:
    """Edit-script <-> id mapping, built from the training pool."""

    def __init__(self, scripts: list[str]):
        self.scripts = list(scripts)
        self.script2id = {s: i for i, s in enumerate(self.scripts)}
        self.id2script = {i: s for s, i in self.script2id.items()}

    def __len__(self) -> int:
        return len(self.scripts)

    @classmethod
    def from_sentences(cls, sentences, min_count: int = 1) -> "ScriptVocab":
        from collections import Counter
        c = Counter(
            derive_best(w.form, w.lemma).encode()
            for sent in sentences for w in sent
        )
        keep = sorted(s for s, n in c.items() if n >= min_count)
        return cls(keep)

    def to_json(self, path) -> None:
        import json, pathlib
        pathlib.Path(path).write_text(
            json.dumps(self.scripts, ensure_ascii=False, indent=2), encoding="utf-8"
        )

    @classmethod
    def from_json(cls, path) -> "ScriptVocab":
        import json, pathlib
        return cls(json.loads(pathlib.Path(path).read_text(encoding="utf-8")))


@dataclass
class Encoded:
    input_ids: torch.Tensor
    attention_mask: torch.Tensor
    tag_labels: torch.Tensor
    script_labels: torch.Tensor
    word_index: list[list[int]]   # per sentence: subword position of each word's first piece


def encode_sentence(
    words: list[Word],
    tokenizer,
    label2id: dict[str, int] | None = None,
    script2id: dict[str, int] | None = None,
    inventory: list[str] | None = None,
    max_length: int = 256,
):
    """Tokenise one sentence and align labels to first subwords.

    Returns (input_ids, attention_mask, tag_labels, script_labels, first_positions).
    Labels are None-safe: pass no label maps to encode for inference only.
    """
    enc = tokenizer(
        [w.form for w in words],
        is_split_into_words=True,
        truncation=True,
        max_length=max_length,
    )
    word_ids = enc.word_ids()

    n_sub = len(enc["input_ids"])
    tag_labels = [IGNORE] * n_sub
    script_labels = [IGNORE] * n_sub
    first_positions: list[int] = []

    seen: set[int] = set()
    for pos, wid in enumerate(word_ids):
        if wid is None or wid in seen:
            continue                     # special token, or a non-first subword
        seen.add(wid)
        first_positions.append(pos)
        w = words[wid]
        if label2id is not None:
            tag = composite_tag(w.upos, w.feats, inventory)
            # An unseen tag cannot be a target; skip it rather than crash. It will
            # simply be unlearnable, which the ceiling measurement already accounts for.
            tag_labels[pos] = label2id.get(tag, IGNORE)
        if script2id is not None:
            script = derive_best(w.form, w.lemma).encode()
            script_labels[pos] = script2id.get(script, IGNORE)

    # Truncation may drop trailing words entirely; first_positions then covers
    # fewer words than `words`. Callers must use len(first_positions), not len(words).
    return enc["input_ids"], enc["attention_mask"], tag_labels, script_labels, first_positions


def collate(batch, pad_id: int):
    """Pad a batch of encoded sentences."""
    maxlen = max(len(b[0]) for b in batch)
    ids, mask, tags, scripts, index = [], [], [], [], []
    for input_ids, attn, tag_l, script_l, first in batch:
        pad = maxlen - len(input_ids)
        ids.append(input_ids + [pad_id] * pad)
        mask.append(attn + [0] * pad)
        tags.append(tag_l + [IGNORE] * pad)
        scripts.append(script_l + [IGNORE] * pad)
        index.append(first)
    return Encoded(
        input_ids=torch.tensor(ids, dtype=torch.long),
        attention_mask=torch.tensor(mask, dtype=torch.long),
        tag_labels=torch.tensor(tags, dtype=torch.long),
        script_labels=torch.tensor(scripts, dtype=torch.long),
        word_index=index,
    )
