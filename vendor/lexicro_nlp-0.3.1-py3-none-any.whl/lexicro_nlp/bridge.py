"""Stage 0 — MULTEXT-East (Romanian MSD) -> Universal Dependencies bridge.

Deterministic converter from a Romanian MSD tag (as found in RoLEX and in the
RRT `XPOS` column) to a UD `(UPOS, FEATS)` pair. This is the piece that lets
RoLEX act as a label source and an inference-time constraint in UD space.

Design
------
* MSDs are positional. Each category has a fixed schema mapping a *character
  index* to an attribute + a code->UD-feature map. Indices are absolute, so
  gaps are real: the verb Clitic attribute lives at position 10, with 7-9 held
  as filler dashes (`Vmip1s----y`); the pronoun Pronoun_Form lives at position
  14 (`Pp3-sd--------w`). A `-` (or an absent trailing position) means "not
  applicable" and is skipped.
* Category schemas are transcribed from the MULTEXT-East V4/V5 Romanian
  specification (https://nl.ijs.si/ME/Vault/V5/msd/html/msd-ro.html, CC BY-SA),
  and every UD target string was verified against UD_Romanian-RRT rather than
  assumed. Non-obvious targets that a from-memory table would get wrong:
    - direct case  -> `Case=Acc,Nom`  (never `Nom,Acc`; UD sorts alphabetically)
    - oblique case -> `Case=Dat,Gen`
    - Clitic=yes   -> `Variant=Short` (NOT dropped; verified 100% on N/V/A/P/
                      T/R/S/C/Q in RRT. Determiner is the lone exception, where
                      RRT emits nothing -- honoured below.)
    - Owner_Number -> `Number[psor]`
    - Modific_Type -> `Position=Prenom|Postnom`
    - Pronoun_Form -> `Strength=Strong|Weak`
* Romanian neuter: MSD encodes an explicit neuter gender, but RRT (following the
  documented Romanian declension rule) realises it as masculine in the singular
  and feminine in the plural. The bridge applies that rule, resolving neuter by
  Number. RRT never emits `Gender=Neut`.

What the bridge cannot do
-------------------------
Some RRT features are *contextual*, not lexical: `ExtPos` (on fixed multiword
expressions) and a handful of others depend on the sentence, not on the tag. No
lexical converter can produce them, and their absence is the honest ceiling on
FEATS-exact agreement -- not a bug.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Iterable

# Sentinel: Romanian neuter, resolved to Masc/Fem by Number in post-processing.
NEUTER = "__NEUTER__"
# A recognised code that intentionally emits no UD feature.
DROP: dict[str, str] = {}

# ---- reusable value maps (code -> UD features to merge) -------------------

_GENDER = {"m": {"Gender": "Masc"}, "f": {"Gender": "Fem"}, "n": {"Gender": NEUTER}}
_NUMBER = {"s": {"Number": "Sing"}, "p": {"Number": "Plur"}}
_DEFINITE = {"n": {"Definite": "Ind"}, "y": {"Definite": "Def"}}
_DEGREE = {"p": {"Degree": "Pos"}, "c": {"Degree": "Cmp"}, "s": {"Degree": "Sup"}}
_PERSON = {"1": {"Person": "1"}, "2": {"Person": "2"}, "3": {"Person": "3"}}

# Clitic=yes surfaces in RRT as Variant=Short (verified; see module docstring).
_CLITIC = {"n": DROP, "y": {"Variant": "Short"}}
# Determiner is the documented exception: RRT emits nothing for its clitic.
_CLITIC_DROP = {"n": DROP, "y": DROP}

# Nominal case: only the three syncretic values.
_CASE = {"r": {"Case": "Acc,Nom"}, "o": {"Case": "Dat,Gen"}, "v": {"Case": "Voc"}}
# Pronominal case: full five plus the two syncretic values.
_CASE_PRON = {
    "n": {"Case": "Nom"},
    "g": {"Case": "Gen"},
    "d": {"Case": "Dat"},
    "a": {"Case": "Acc"},
    "v": {"Case": "Voc"},
    "r": {"Case": "Acc,Nom"},
    "o": {"Case": "Dat,Gen"},
}
# Determiner case: direct/oblique only.
_CASE_DET = {"r": {"Case": "Acc,Nom"}, "o": {"Case": "Dat,Gen"}}

_OWNER_NUMBER = {"s": {"Number[psor]": "Sing"}, "p": {"Number[psor]": "Plur"}}
_MODIFIC = {"e": {"Position": "Prenom"}, "o": {"Position": "Postnom"}}
_PRON_FORM = {"s": {"Strength": "Strong"}, "w": {"Strength": "Weak"}}

_VFORM = {
    "i": {"Mood": "Ind", "VerbForm": "Fin"},
    "s": {"Mood": "Sub", "VerbForm": "Fin"},
    "m": {"Mood": "Imp", "VerbForm": "Fin"},
    "n": {"VerbForm": "Inf"},
    "p": {"VerbForm": "Part"},
    "g": {"VerbForm": "Ger"},
}
_VTENSE = {"p": {"Tense": "Pres"}, "i": {"Tense": "Imp"}, "s": {"Tense": "Past"}, "l": {"Tense": "Pqp"}}

# Pronoun Type -> UD. Reflexive and possessive carry an extra feature.
_PRON_TYPE = {
    "p": {"PronType": "Prs"},
    "d": {"PronType": "Dem"},
    "i": {"PronType": "Ind"},
    "s": {"PronType": "Prs", "Poss": "Yes"},
    "x": {"PronType": "Prs", "Reflex": "Yes"},
    "z": {"PronType": "Neg"},
    "w": {"PronType": "Int,Rel"},
}
_DET_TYPE = {
    "d": {"PronType": "Dem"},
    "i": {"PronType": "Ind"},
    "s": {"PronType": "Prs", "Poss": "Yes"},
    "w": {"PronType": "Int,Rel"},
    "z": {"PronType": "Neg"},
    "h": {"PronType": "Emp"},
}
_ART_TYPE = {
    "f": {"PronType": "Art", "Definite": "Def"},   # definite article
    "i": {"PronType": "Ind"},                       # indefinite article
    "s": {"PronType": "Prs", "Poss": "Yes"},        # possessive article
    "d": {"PronType": "Dem"},                       # demonstrative article
}
_ADV_TYPE = {
    "g": DROP,                       # general
    "c": DROP,                       # correlative
    "p": DROP,
    "w": {"PronType": "Int,Rel"},
    "z": {"PronType": "Neg"},
}
_ADP_TYPE = {"p": {"AdpType": "Prep"}}
_ADP_CASE = {"a": {"Case": "Acc"}, "g": {"Case": "Gen"}, "d": {"Case": "Dat"}}
_NUM_TYPE = {
    "c": {"NumType": "Card"},
    "o": {"NumType": "Ord"},
    "f": {"NumType": "Card"},                       # fractal: RRT emits Card
    "l": {"NumType": "Card", "PronType": "Tot"},    # 'toți/toate' collective
    "m": {"NumType": "Mult"},
}
_NUM_FORM = {
    "d": {"NumForm": "Digit"},
    "l": {"NumForm": "Word"},
    "r": {"NumForm": "Roman"},
    "b": {"NumForm": "Combi"},   # digit+letter combination (e.g. "10-lea")
}
_PART_TYPE = {
    "s": {"Mood": "Sub"},
    "z": {"Polarity": "Neg"},
    "n": {"PartType": "Inf"},
    "f": {"Tense": "Fut"},
}
_POLARITY = {"p": {"Polarity": "Pos"}, "n": {"Polarity": "Neg"}}


@dataclass(frozen=True)
class CategorySchema:
    upos: Callable[[str], str]              # type-char -> UPOS
    type_pos: int                           # char index of the Type attribute
    positions: dict[int, tuple[str, dict]]  # char index -> (attr name, code map)


SCHEMA: dict[str, CategorySchema] = {
    # --- open classes -----------------------------------------------------
    "N": CategorySchema(
        upos=lambda t: {"c": "NOUN", "p": "PROPN"}.get(t, "NOUN"),
        type_pos=1,
        positions={
            2: ("Gender", _GENDER),
            3: ("Number", _NUMBER),
            4: ("Case", _CASE),
            5: ("Definite", _DEFINITE),
            6: ("Clitic", _CLITIC),
        },
    ),
    "V": CategorySchema(
        upos=lambda t: {"m": "VERB", "o": "VERB", "a": "AUX", "c": "AUX"}.get(t, "VERB"),
        type_pos=1,
        positions={
            2: ("VForm", _VFORM),
            3: ("Tense", _VTENSE),
            4: ("Person", _PERSON),
            5: ("Number", _NUMBER),
            6: ("Gender", _GENDER),
            10: ("Clitic", _CLITIC),
        },
    ),
    "A": CategorySchema(
        upos=lambda t: "ADJ",
        type_pos=1,
        positions={
            2: ("Degree", _DEGREE),
            3: ("Gender", _GENDER),
            4: ("Number", _NUMBER),
            5: ("Case", _CASE),
            6: ("Definite", _DEFINITE),
            7: ("Clitic", _CLITIC),
        },
    ),
    # --- closed classes ---------------------------------------------------
    "P": CategorySchema(   # Pronoun
        upos=lambda t: "PRON",
        type_pos=1,
        positions={
            1: ("Type", _PRON_TYPE),
            2: ("Person", _PERSON),
            3: ("Gender", _GENDER),
            4: ("Number", _NUMBER),
            5: ("Case", _CASE_PRON),
            6: ("Owner_Number", _OWNER_NUMBER),
            8: ("Clitic", _CLITIC),
            14: ("Pronoun_Form", _PRON_FORM),
        },
    ),
    "D": CategorySchema(   # Determiner
        upos=lambda t: "DET",
        type_pos=1,
        positions={
            1: ("Type", _DET_TYPE),
            2: ("Person", _PERSON),
            3: ("Gender", _GENDER),
            4: ("Number", _NUMBER),
            5: ("Case", _CASE_DET),
            6: ("Owner_Number", _OWNER_NUMBER),
            8: ("Clitic", _CLITIC_DROP),   # RRT emits nothing here (verified)
            9: ("Modific_Type", _MODIFIC),
        },
    ),
    "T": CategorySchema(   # Article
        upos=lambda t: "DET",
        type_pos=1,
        positions={
            1: ("Type", _ART_TYPE),
            2: ("Gender", _GENDER),
            3: ("Number", _NUMBER),
            4: ("Case", _CASE_DET),
            5: ("Clitic", _CLITIC),
        },
    ),
    "M": CategorySchema(   # Numeral
        upos=lambda t: "NUM",
        type_pos=1,
        positions={
            1: ("Type", _NUM_TYPE),
            2: ("Gender", _GENDER),
            3: ("Number", _NUMBER),
            4: ("Case", _CASE_DET),
            5: ("Form", _NUM_FORM),
            6: ("Definite", _DEFINITE),
            7: ("Clitic", _CLITIC),
        },
    ),
    "R": CategorySchema(   # Adverb
        upos=lambda t: "ADV",
        type_pos=1,
        positions={
            1: ("Type", _ADV_TYPE),
            2: ("Degree", _DEGREE),
            3: ("Clitic", _CLITIC),
        },
    ),
    "S": CategorySchema(   # Adposition
        upos=lambda t: "ADP",
        type_pos=1,
        positions={
            1: ("Type", _ADP_TYPE),
            # 2: Formation (simple/compound) -- no UD equivalent
            3: ("Case", _ADP_CASE),
            4: ("Clitic", _CLITIC),
        },
    ),
    "C": CategorySchema(   # Conjunction: 's' subordinating, else coordinating
        upos=lambda t: "SCONJ" if t == "s" else "CCONJ",
        type_pos=1,
        positions={
            4: ("Polarity", _POLARITY),
            5: ("Clitic", _CLITIC),
        },
    ),
    "Q": CategorySchema(   # Particle
        upos=lambda t: "PART",
        type_pos=1,
        positions={
            1: ("Type", _PART_TYPE),
            3: ("Clitic", _CLITIC),
        },
    ),
}

# Categories with no morphology to emit.
# X (residual): RRT sometimes adds Foreign=Yes, but that is a contextual
# judgement about the token, not information carried by the tag -- so we emit
# nothing rather than guess.
UPOS_ONLY: dict[str, str] = {
    "I": "INTJ",
    "X": "X",
}

# Abbreviation (Y). Position 1 holds the *underlying category letter*, and the
# remaining positions reuse that category's schema at the same absolute indices
# (verified: `Ynmsry` mirrors `Ncmsry`). Every abbreviation gets Abbr=Yes.
_ABBR_CATEGORY = {"n": "N", "a": "A", "r": "R", "p": "P", "m": "M", "v": "V"}


@dataclass
class Conversion:
    upos: str | None
    feats: dict = field(default_factory=dict)
    unmapped: list[str] = field(default_factory=list)   # loud gaps, never silent

    @property
    def ok(self) -> bool:
        return self.upos is not None and not self.unmapped


def _char(msd: str, i: int) -> str:
    return msd[i] if i < len(msd) else "-"


def _is_punct_tag(msd: str) -> bool:
    # RRT encodes punctuation as all-caps names (COMMA, PERIOD, LPAR, SLASH...).
    # These collide with real category letters (S, R, C, Q), so the test must be
    # on the whole tag, not its first character. RoLEX, a word lexicon, has none.
    return len(msd) > 2 and msd.isalpha() and msd.isupper()


def msd_to_ud(msd: str) -> Conversion:
    """Convert one MSD string to a UD `(UPOS, FEATS)` pair."""
    if not msd or msd == "_":
        return Conversion(None, unmapped=["empty MSD"])

    if _is_punct_tag(msd):
        return Conversion("PUNCT")

    cat = msd[0]

    if cat == "Y":
        return _convert_abbreviation(msd)

    if cat in SCHEMA:
        return _apply_schema(cat, msd)

    if cat in UPOS_ONLY:
        return Conversion(UPOS_ONLY[cat])

    return Conversion(None, unmapped=[f"unknown category {cat!r} in {msd!r}"])


def _apply_schema(cat: str, msd: str, extra: dict | None = None,
                  skip: set[int] | None = None) -> Conversion:
    spec = SCHEMA[cat]
    conv = Conversion(upos=spec.upos(_char(msd, spec.type_pos)))
    if extra:
        conv.feats.update(extra)
    for pos, (attr, vmap) in spec.positions.items():
        if skip and pos in skip:
            continue
        ch = _char(msd, pos)
        if ch == "-":
            continue
        merge = vmap.get(ch)
        if merge is None:
            conv.unmapped.append(f"{cat}: pos{pos} {attr}={ch!r} not in map")
        else:
            conv.feats.update(merge)
    _resolve_neuter(conv)
    return conv


def _convert_abbreviation(msd: str) -> Conversion:
    """`Y<cat><rest>`: an abbreviation of an underlying category.

    The underlying category's schema applies at the same absolute positions, so
    `Ynmsry` is read exactly like `Ncmsry`, plus `Abbr=Yes`. Position 1 holds the
    underlying category letter rather than that category's Type code, so it is
    skipped. A bare `Y` has no underlying category and stays X.
    """
    under = _char(msd, 1)
    if under == "-":
        return Conversion("X", feats={"Abbr": "Yes"})
    cat = _ABBR_CATEGORY.get(under)
    if cat is None:
        return Conversion("X", feats={"Abbr": "Yes"},
                          unmapped=[f"Y: unknown underlying category {under!r}"])
    conv = _apply_schema(cat, msd, extra={"Abbr": "Yes"}, skip={1})
    conv.upos = {"N": "NOUN", "A": "ADJ", "R": "ADV", "P": "PRON",
                 "M": "NUM", "V": "VERB"}[cat]
    return conv


def _resolve_neuter(conv: Conversion) -> None:
    if conv.feats.get("Gender") != NEUTER:
        return
    number = conv.feats.get("Number")
    if number == "Sing":
        conv.feats["Gender"] = "Masc"
    elif number == "Plur":
        conv.feats["Gender"] = "Fem"
    else:
        # Neuter with no number to disambiguate: drop rather than guess.
        del conv.feats["Gender"]
        conv.unmapped.append("neuter gender without number; Gender dropped")


# ---- coverage report over an MSD inventory (e.g. the RoLEX tagset) ---------

@dataclass
class BridgeReport:
    total: int = 0
    recognised: int = 0        # UPOS assigned
    fully_mapped: int = 0      # UPOS + every present position mapped
    unknown: int = 0           # category not recognised
    by_category: dict = field(default_factory=dict)
    unmapped_notes: dict = field(default_factory=dict)

    def summary(self) -> str:
        lines = [
            f"MSDs seen:        {self.total}",
            f"  recognised:     {self.recognised} ({self._pct(self.recognised)})",
            f"  fully mapped:   {self.fully_mapped} ({self._pct(self.fully_mapped)})",
            f"  unknown cat.:   {self.unknown} ({self._pct(self.unknown)})",
            "",
            "by category (UPOS): " + ", ".join(
                f"{c}:{n}" for c, n in sorted(self.by_category.items())
            ),
        ]
        if self.unmapped_notes:
            lines.append("")
            lines.append("unmapped positions (itemised):")
            for note, n in sorted(self.unmapped_notes.items(), key=lambda kv: -kv[1]):
                lines.append(f"  {n:>6}  {note}")
        return "\n".join(lines)

    def _pct(self, n: int) -> str:
        return f"{n / self.total:.1%}" if self.total else "0.0%"


def coverage(msds: Iterable[str]) -> BridgeReport:
    """Run the bridge over an MSD inventory and report what maps and what doesn't.

    Point this at the RoLEX MSD inventory (or the XPOS column of any CoNLL-U) to
    see exactly which categories/positions still need mapping.
    """
    rep = BridgeReport()
    for msd in msds:
        rep.total += 1
        conv = msd_to_ud(msd)
        if conv.upos is None:
            rep.unknown += 1
        else:
            rep.recognised += 1
            rep.by_category[conv.upos] = rep.by_category.get(conv.upos, 0) + 1
            if not conv.unmapped:
                rep.fully_mapped += 1
        for note in conv.unmapped:
            rep.unmapped_notes[note] = rep.unmapped_notes.get(note, 0) + 1
    return rep
