"""LexicRo NLP — Phase 2 morphological analysis pipeline.

Licence-free MVP lane: data loading, composite-tag label space, edit-script
lemmatisation, and an evaluation harness. None of this depends on RoLEX; the
RoLEX accuracy layer (constrained decoding + silver data) plugs in later via
the `known_forms` hook in the scorer and the MSD->UD bridge (Stage 0).
"""

from .data import Word, iter_sentences, load_pool, build_vocab, find_conllu
from .labels import (
    canonical_feats,
    composite_tag,
    split_tag,
    parse_feats_str,
    LabelSpace,
)
from .lemma import EditScript, derive, derive_best
from .lexicon import Lexicon
from .tokenizer import tokenize, split_sentences, tokenize_sentence
from .analyzer import Analyzer, Token
from .eval import Metrics, Scorer, format_report
from .bridge import Conversion, msd_to_ud, coverage, BridgeReport

__all__ = [
    "Word",
    "iter_sentences",
    "load_pool",
    "build_vocab",
    "find_conllu",
    "canonical_feats",
    "composite_tag",
    "split_tag",
    "parse_feats_str",
    "LabelSpace",
    "EditScript",
    "derive",
    "derive_best",
    "Metrics",
    "Scorer",
    "format_report",
    "Conversion",
    "msd_to_ud",
    "coverage",
    "BridgeReport",
    "Lexicon",
    "tokenize",
    "split_sentences",
    "tokenize_sentence",
    "Analyzer",
    "Token",
]
