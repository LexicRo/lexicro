"""Production inference for `/analyze`.

Loads a self-contained export (see scripts/export_model.py) -- weights,
tokenizer, vocabularies and lexicon all local. No HuggingFace call at runtime:
a serving container that phones home on startup is a container that fails when
the network hiccups.

Serving decisions, and why:

* **Load once.** The model and the 352k-form lexicon are built at process start
  and reused. Per-request loading would dominate latency entirely.
* **Tags are decoded unconstrained.** Measured: constraining the tag head to
  lexicon candidates costs 2.7 points of accuracy, because MULTEXT-East and UD
  disagree systematically on copulas (AUX/VERB), participles (ADJ/VERB) and
  compound prepositions. The lexicon is used for lemmas only.
* **Lemma = lookup when known, model when not.** ~73% of tokens resolve to an
  exact lexicon lemma; the rest fall to the neural edit-script head.
* **`model_version` on every response.** Same input + same version = identical
  output. Weights, lexicon snapshot and MSD->UD table are versioned together.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

import torch
from transformers import AutoTokenizer

from .encoding import ScriptVocab, encode_sentence
from .labels import LabelSpace, split_tag, parse_feats_str
from .lemma import EditScript
from .lexicon import Lexicon
from .model import MorphTagger
from .tokenizer import tokenize
from .suffix_lemma import OovLemmatizer

@dataclass
class Token:
    form: str
    lemma: str
    upos: str
    feats: dict
    # Provenance of the LEMMA: "lexicon" | "suffix" | "model". NOT a confidence
    # score. None means the token was past the truncation cut and was not
    # analysed at all -- see Analysis.truncated. (ADR-0022)
    source: str | None = None
    # Other readings the lexicon lists for this form, present ONLY when it
    # lists more than one. Reporting only -- never used to constrain decoding
    # (ADR-0015 stands). The reading in this Token's own fields is NOT
    # guaranteed to appear here: the lexicon disagrees with UD on ~6% of
    # tokens.
    candidates: list[dict] | None = None

    def to_dict(self) -> dict:
        d = {
            "form": self.form,
            "lemma": self.lemma,
            "upos": self.upos,
            "feats": self.feats,
        }
        if self.source is not None:
            d["source"] = self.source
        if self.candidates:
            d["candidates"] = self.candidates
        return d


@dataclass
class Analysis:
    """Sentences plus whether anything was dropped producing them."""

    sentences: list[list[Token]]
    truncated: bool = False


class Analyzer:
    def __init__(self, export_dir: str | Path, device: str = "cpu"):
        export_dir = Path(export_dir)
        self.cfg = json.loads((export_dir / "serving.json").read_text(encoding="utf-8"))
        self.model_version = self.cfg["model_version"]
        self.max_length = self.cfg.get("max_length", 256)
        self.device = device

        self.labels = LabelSpace.from_json(export_dir / "label_space.json")
        self.scripts = ScriptVocab.from_json(export_dir / "script_vocab.json")

        # Tokenizer + encoder config are vendored into the export, so
        # from_pretrained reads from disk and never touches the network.
        self.tokenizer = AutoTokenizer.from_pretrained(str(export_dir / "encoder"))

        self.model = self._load_model(export_dir)
        self.model.eval()

        if self.cfg.get("quantized"):
            self.model = torch.quantization.quantize_dynamic(
                self.model, {torch.nn.Linear}, dtype=torch.qint8
            )
        # Serving is CPU-only; .to("cpu") is a no-op that only risks tripping
        # over meta tensors, so skip it entirely in the common case.
        if device != "cpu":
            self.model.to(device)

        lex_path = export_dir / "lexicon" / "wfl-ro.txt"
        self.lexicon = Lexicon.from_wfl(lex_path) if lex_path.exists() else None

        # OOV lemma override: suffix rules + vocabulary. Optional -- without it
        # the OOV path is unchanged, just less accurate.
        oov_path = export_dir / "oov_lemmatizer.json"
        self.oov_lemma = OovLemmatizer.load(oov_path) if oov_path.exists() else None

        # Bound work per request. A caller pasting a novel should get a clean
        # 413, not an OOM that takes the worker down with it.
        self.max_chars = self.cfg.get("max_chars", 20000)

    # ---- loading ---------------------------------------------------------

    def _load_model(self, export_dir: Path) -> MorphTagger:
        """Build the model without ever holding two copies of the weights.

        The naive path -- construct from config, then load_state_dict -- allocates
        a full set of random weights (~500 MB for bert-base), then allocates the
        checkpoint on top, so peak RSS is ~1 GB for a 500 MB model and the OS
        never fully gives it back. The random weights are overwritten immediately;
        allocating them at all is pure waste.

        Instead: build on the `meta` device (structure only, zero storage), then
        `assign=True` the memory-mapped checkpoint tensors directly into place.
        One copy, file-backed, so the kernel can evict pages under pressure.

        Falls back to the naive path (with an explicit free) on older torch.
        """
        kwargs = dict(
            n_tags=self.cfg["n_tags"],
            n_scripts=self.cfg["n_scripts"],
            _config_only=True,
        )
        enc = str(export_dir / "encoder")
        ckpt = export_dir / "model.pt"

        try:
            with torch.device("meta"):
                model = MorphTagger(enc, **kwargs)
            state = torch.load(ckpt, map_location="cpu", mmap=True, weights_only=True)
            model.load_state_dict(state, assign=True)

            # Non-persistent buffers (BERT's position_ids / token_type_ids) are
            # not in the checkpoint, so assign=True leaves them on `meta` with no
            # storage -- and the next .to() call dies on them. They are tiny and
            # deterministic, so just rebuild them.
            for name, buf in list(model.named_buffers()):
                if not buf.is_meta:
                    continue
                mod = model
                *path, leaf = name.split(".")
                for p in path:
                    mod = getattr(mod, p)
                if leaf == "position_ids":
                    fresh = torch.arange(buf.shape[-1]).expand(buf.shape).clone()
                elif leaf == "token_type_ids":
                    fresh = torch.zeros(buf.shape, dtype=torch.long)
                else:
                    fresh = torch.zeros(buf.shape, dtype=buf.dtype)
                mod.register_buffer(leaf, fresh, persistent=False)

            if any(p.is_meta for p in model.parameters()):
                raise RuntimeError("meta parameters remain after assign")
            return model

        except (TypeError, RuntimeError, NotImplementedError):
            # older torch, or a checkpoint not saved in the zipfile format
            import gc
            model = MorphTagger(enc, **kwargs)
            state = torch.load(ckpt, map_location="cpu")
            model.load_state_dict(state)
            del state
            gc.collect()
            return model

    # ---- inference -------------------------------------------------------

    def _known(self, form: str) -> bool:
        return self.lexicon is not None and self.lexicon.known(form)

    @torch.no_grad()
    def analyze(self, text: str) -> Analysis:
        """Raw text -> sentences of analysed tokens, plus a truncation flag."""
        if len(text) > self.max_chars:
            raise ValueError(f"text exceeds {self.max_chars} characters")

        known = self._known if self.lexicon is not None else None
        sentences = tokenize(text, known=known)
        if not sentences:
            return Analysis(sentences=[])

        out: list[list[Token]] = []
        truncated = False
        for forms in sentences:
            tokens, cut = self._analyze_sentence(forms)
            out.append(tokens)
            truncated = truncated or cut
        return Analysis(sentences=out, truncated=truncated)

    def _analyze_sentence(self, forms: list[str]) -> tuple[list[Token], bool]:
        # encode_sentence expects objects with a `.form`; a tiny shim avoids
        # rebuilding Word objects just to read one attribute.
        shim = [_FormOnly(f) for f in forms]
        ids, mask, _, _, first = encode_sentence(
            shim, self.tokenizer, max_length=self.max_length
        )
        input_ids = torch.tensor([ids], device=self.device)
        attn = torch.tensor([mask], device=self.device)

        tag_ids, script_ids = self.model.predict(input_ids, attn, None)

        tokens: list[Token] = []
        truncated = False
        for i, form in enumerate(forms):
            if i >= len(first):
                # Past max_length. Emit the form rather than dropping it, but
                # with no `source`: nothing analysed it. (ADR-0022)
                tokens.append(Token(form, form, "X", {}))
                truncated = True
                continue
            pos = first[i]
            tag = self.labels.id2label[int(tag_ids[0, pos])]
            upos, feats_str = split_tag(tag)

            lemma, source = None, "model"
            if self.lexicon is not None:
                lemma = self.lexicon.lemma_for(form, tag)
                if lemma is not None:
                    source = "lexicon"

            if lemma is None:  # OOV path: neural edit script
                script = EditScript.decode(self.scripts.id2script[int(script_ids[0, pos])])
                lemma = script.apply(form) or form
                if self.oov_lemma is not None:
                    lemma, source = self.oov_lemma.resolve(
                        form, upos, parse_feats_str(feats_str), lemma
                    )

            # Reporting only -- never fed back into the decode. (ADR-0015)
            cands = self.lexicon.readings(form) if self.lexicon is not None else []
            tokens.append(
                Token(
                    form,
                    lemma,
                    upos,
                    parse_feats_str(feats_str),
                    source,
                    cands if len(cands) > 1 else None,
                )
            )
        return tokens, truncated

    def info(self) -> dict:
        return {
            "model_version": self.model_version,
            "quantized": bool(self.cfg.get("quantized")),
            "n_tags": self.cfg["n_tags"],
            "n_scripts": self.cfg["n_scripts"],
            "lexicon_forms": len(self.lexicon) if self.lexicon else 0,
            "max_chars": self.max_chars,
        }


class _FormOnly:
    __slots__ = ("form", "lemma", "upos", "feats")

    def __init__(self, form: str):
        self.form = form
        self.lemma = form
        self.upos = "X"
        self.feats = {}
