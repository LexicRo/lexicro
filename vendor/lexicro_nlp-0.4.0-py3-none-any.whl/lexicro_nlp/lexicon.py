"""Lexicon layer — the hybrid seam.

Loads a MULTEXT-East word-form lexicon (`form <TAB> lemma <TAB> MSD`, one entry
per line) and bridges every MSD to UD, producing per-form candidates:

    form (casefolded) -> [(composite_tag, lemma), ...]

That single structure serves both halves of the hybrid:

* **Constrained tag decoding.** The candidate tags for a form are the only tags
  it can legally take, so the tag head's logits are masked to them. A constraint
  only ever removes options, so it is strictly beneficial and needs no retraining.

* **Exact lemma lookup.** Once the tag is decided, `(form, tag) -> lemma` is a
  dictionary read. This is what turns lemma from a prediction into a lexical
  fact -- and it is where the accuracy lives, because a lemma is not inferable
  from context the way morphology is. You either know the word or you don't.

Tokens absent from the lexicon fall through to the neural path unchanged. That
is the OOV route, and it stays honest: no guessing dressed up as lookup.

Casing: keys are casefolded (sentence-initial capitals must still match), while
lemmas are returned exactly as the lexicon stores them, so `Washingtonului` ->
`Washington` keeps its capital.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from pathlib import Path

from .bridge import msd_to_ud
from .labels import composite_tag, parse_feats_str, split_tag


class Lexicon:
    def __init__(self, entries: dict[str, list[tuple[str, str]]]):
        # form_cf -> list of (composite_tag, lemma)
        self.entries = entries

    def __len__(self) -> int:
        return len(self.entries)

    @classmethod
    def from_wfl(
        cls,
        path: str | Path,
        inventory: list[str] | None = None,
    ) -> "Lexicon":
        """Load a MULTEXT-East word-form lexicon and bridge its MSDs to UD."""
        entries: dict[str, list[tuple[str, str]]] = defaultdict(list)
        skipped = 0
        with open(path, encoding="utf-8", errors="replace") as fh:
            for line in fh:
                parts = line.rstrip("\n").split("\t")
                if len(parts) < 3 or not (parts[0] and parts[1] and parts[2]):
                    skipped += 1
                    continue
                form, lemma, msd = parts[0], parts[1], parts[2]
                conv = msd_to_ud(msd)
                if conv.upos is None:
                    skipped += 1
                    continue
                tag = composite_tag(conv.upos, conv.feats, inventory)
                pair = (tag, lemma)
                bucket = entries[form.casefold()]
                if pair not in bucket:      # dedupe: many MSDs collapse to one UD tag
                    bucket.append(pair)
        obj = cls(dict(entries))
        obj.skipped = skipped
        return obj

    # ---- constrained decoding ------------------------------------------

    def candidate_tags(self, form: str) -> list[str]:
        return [t for t, _ in self.entries.get(form.casefold(), ())]

    def candidate_tag_ids(self, form: str, label2id: dict[str, int]) -> set[int]:
        """Tag ids allowed for this form. Empty set = unknown form (OOV path).

        A tag the model has never seen (absent from label2id) cannot be decoded,
        so it is dropped from the candidate set rather than silently widening it.
        """
        ids = {label2id[t] for t in self.candidate_tags(form) if t in label2id}
        return ids

    # ---- reporting: what else could this form be? -----------------------

    def readings(self, form: str) -> list[dict]:
        """Every distinct reading the lexicon lists for this form.

        Returns [{"lemma", "upos", "feats"}, ...] with duplicates collapsed;
        an empty list means the form is not in the lexicon.

        REPORTING ONLY. This never influences decoding. ADR-0015 retired
        lexicon-constrained decoding and ADR-0022 did not bring it back --
        these readings are returned to the caller, never used to mask, filter
        or rank the tag head. Do not wire this into `predict`.
        """
        bucket = self.entries.get(form.casefold())
        if not bucket:
            return []

        seen: set[tuple[str, str, str]] = set()
        out: list[dict] = []
        for tag, lemma in bucket:
            upos, feats_str = split_tag(tag)
            key = (lemma, upos, feats_str)
            if key in seen:
                continue
            seen.add(key)
            out.append(
                {"lemma": lemma, "upos": upos, "feats": parse_feats_str(feats_str)}
            )
        return out

    # ---- exact lemma lookup ---------------------------------------------

    # UD and MULTEXT-East disagree systematically on some UPOS assignments, and
    # the disagreements are structural, not random:
    #   AUX/VERB   -- copulas and auxiliaries ("era", "fusese", "vor")
    #   NOUN/PROPN
    #   DET/PRON   -- determiner vs pronoun depends on whether a head noun follows
    #   ADJ/VERB   -- participles are lexicalised as adjectives in MTE
    # So a UPOS mismatch does NOT mean a different lexical entry. These classes
    # let a predicted AUX still match a VERB entry.
    _UPOS_CLASS = {
        "VERB": "V", "AUX": "V",
        "NOUN": "N", "PROPN": "N",
        "DET": "D", "PRON": "D",
    }

    @classmethod
    def _upos_class(cls, upos: str) -> str:
        return cls._UPOS_CLASS.get(upos, upos)

    def lemma_for(self, form: str, tag: str | None = None) -> str | None:
        """Lemma for (form, tag). None = not in the lexicon, use the neural path.

        Resolution order:
          1. exact (form, tag) match -- the normal case;
          2. the form is lemma-unambiguous, so the tag cannot change the answer
             and a wrong tag prediction is harmless;
          3. otherwise SCORE the candidates against the predicted tag and take
             the best. Scoring beats guessing: `era` is both the imperfect of
             *a fi* (lemma `fi`) and the definite singular of *eră* (lemma `eră`).
             The model predicts AUX; MULTEXT-East stores the verb as VERB; so the
             exact match fails and a naive fallback returns an arbitrary lemma --
             which was exactly the bug. But the predicted FEATS
             {Mood, Tense, Person, Number, VerbForm} overlap the verb entry
             completely and the noun entry barely at all, so the right answer is
             recoverable with no guessing.
        """
        bucket = self.entries.get(form.casefold())
        if not bucket:
            return None

        if tag is None:
            lemmas = {lemma for _, lemma in bucket}
            if len(lemmas) == 1:
                return next(iter(lemmas))
            return Counter(lemma for _, lemma in bucket).most_common(1)[0][0]

        # 1. exact match
        for t, lemma in bucket:
            if t == tag:
                return lemma

        # 2. lemma-unambiguous: the tag is irrelevant, so a tag error cannot hurt
        lemmas = {lemma for _, lemma in bucket}
        if len(lemmas) == 1:
            return next(iter(lemmas))

        # 3. score by agreement with the predicted tag
        want_upos, want_feats = self._parse(tag)
        want_cls = self._upos_class(want_upos)

        best, best_score = None, float("-inf")
        for cand_tag, lemma in bucket:
            cand_upos, cand_feats = self._parse(cand_tag)
            score = 0.0
            if cand_upos == want_upos:
                score += 4.0
            elif self._upos_class(cand_upos) == want_cls:
                score += 3.0        # AUX vs VERB: same lexical entry, different convention
            # agreement on feature VALUES, not just feature names
            score += sum(1.0 for k, v in want_feats.items() if cand_feats.get(k) == v)
            # mild penalty for features the candidate asserts that the model did not
            score -= 0.25 * sum(1 for k in cand_feats if k not in want_feats)
            if score > best_score:
                best, best_score = lemma, score
        return best

    @staticmethod
    def _parse(tag: str) -> tuple[str, dict]:
        upos, _, feats_str = tag.partition("|")
        if feats_str in ("", "_"):
            return upos, {}
        feats = {}
        for pair in feats_str.split("|"):
            k, _, v = pair.partition("=")
            if v:
                feats[k] = v
        return upos, feats

    def known(self, form: str) -> bool:
        return form.casefold() in self.entries

    def forms(self) -> set[str]:
        """Casefolded surface inventory -- use as `known_forms` in the scorer."""
        return set(self.entries)

    # ---- lemma-head training data ---------------------------------------

    def training_pairs(self) -> list[tuple[str, str, str]]:
        """(form, lemma, tag) triples for pretraining the OOV edit-script head.

        Type-level, not token-level: each form appears once regardless of corpus
        frequency. That is exactly the distribution the OOV path faces at serve
        time, so it is the right sample to learn from.
        """
        out: list[tuple[str, str, str]] = []
        for form_cf, bucket in self.entries.items():
            for tag, lemma in bucket:
                out.append((form_cf, lemma, tag))
        return out

    def stats(self) -> str:
        n_entries = sum(len(v) for v in self.entries.values())
        ambiguous = sum(
            1 for v in self.entries.values() if len({lemma for _, lemma in v}) > 1
        )
        return (
            f"forms: {len(self.entries)}  |  (tag, lemma) pairs: {n_entries}  |  "
            f"lemma-ambiguous forms: {ambiguous} ({ambiguous / max(len(self.entries), 1):.2%})"
        )
