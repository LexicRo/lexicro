"""Deterministic suffix-rule lemmatisation for out-of-vocabulary words.

Why this exists
---------------
The neural lemma head predicts an *edit script* from BERT's first subword. Two
problems compound there:

1. First-subword pooling is right for tagging and close to worst for
   lemmatisation. An edit rule is determined almost entirely by the word's
   SUFFIX, and for an OOV word split into many subwords the first subword is
   where the ending is least visible.

2. More seriously, the edit-script representation stores the kept prefix as an
   ABSOLUTE character index, so a script does not transfer between words of
   different lengths. The rule learned from `mașinile -> mașină` ("keep 5 chars,
   append ă") yields `gradinile -> gradiă`. Measured on RRT, 95.5% of OOV lemma
   errors are the model picking a script that exists in its vocabulary but whose
   prefix length does not fit the word in front of it -- `pașapoartele ->
   pașapoa`, `băiețelul -> băiețe`. That is a representational flaw, not a data
   shortage.

This module uses RELATIVE rules -- strip N characters from the end, append X --
which transfer correctly across word lengths, and learns them from the lexicon:

    (upos, key-feats, last-k-characters) -> most frequent (strip, append)

Inference takes the longest suffix that has a rule and backs off. Properties
that matter: it is deterministic (so it fits the `model_version` contract
without qualification), it needs no GPU, and it is trained on ~428k type-level
lexicon pairs rather than ~30k unique treebank forms -- type-level being exactly
the distribution an OOV word is drawn from.

This is a candidate for the OOV path only; in-lexicon words are still answered
by exact lookup. Whether it beats the neural head is a measurement, not an
assumption -- see scripts/eval_suffix_lemma.py.
"""

from __future__ import annotations

import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Iterable

# Beyond UPOS, Romanian nominal morphology keys heavily off number and
# definiteness: `-e` on a plural noun and `-e` on a feminine singular want
# different rules.
DEFAULT_KEY_FEATS = ("Number",)


def derive_rule(form: str, lemma: str, lower: bool = True) -> tuple[int, str, bool]:
    """(strip, append, lower) -- relative to the END of the word, so it transfers."""
    f = form.casefold() if lower else form
    n = min(len(f), len(lemma))
    i = 0
    while i < n and f[i] == lemma[i]:
        i += 1
    return (len(f) - i, lemma[i:], lower)


def apply_rule(rule: tuple[int, str, bool], form: str) -> str | None:
    strip, append, lower = rule
    f = form.casefold() if lower else form
    if strip > len(f):
        return None
    out = f[: len(f) - strip] + append
    return out or None


def derive_best_rule(form: str, lemma: str) -> tuple[int, str, bool]:
    """Prefer the casefolded rule (shares across the lexicon); fall back to
    literal for case-preserving lemmas such as proper nouns."""
    for low in (True, False):
        r = derive_rule(form, lemma, low)
        if apply_rule(r, form) == lemma:
            return r
    return derive_rule(form, lemma, False)


def _enc(rule: tuple[int, str, bool]) -> str:
    strip, append, lower = rule
    return f"{int(lower)}|{strip}|{append}"


def _dec(s: str) -> tuple[int, str, bool]:
    low, strip, append = s.split("|", 2)
    return (int(strip), append, bool(int(low)))


class SuffixLemmatizer:
    def __init__(
        self,
        rules: dict[str, str],
        max_suffix: int = 8,
        key_feats: tuple[str, ...] = DEFAULT_KEY_FEATS,
    ):
        self.rules = rules          # "upos|featsig|suffix" -> encoded rule
        self.max_suffix = max_suffix
        self.key_feats = tuple(key_feats)

    def __len__(self) -> int:
        return len(self.rules)

    @staticmethod
    def _key(upos: str, sig: str, suffix: str) -> str:
        return f"{upos}|{sig}|{suffix}"

    def _sig(self, feats: dict) -> str:
        if not self.key_feats:
            return ""
        return ",".join(f"{k}={feats[k]}" for k in self.key_feats if k in feats)

    @classmethod
    def from_pairs(
        cls,
        pairs: Iterable[tuple[str, str, str, dict]],
        max_suffix: int = 8,
        min_count: int = 1,
        min_purity: float = 0.0,
        key_feats: tuple[str, ...] = DEFAULT_KEY_FEATS,
    ) -> "SuffixLemmatizer":
        """Build from (form, lemma, upos, feats).

        `min_purity` optionally refuses a rule whose winning outcome does not
        account for at least that share of the suffix's occurrences -- declining
        to guess where a suffix is genuinely ambiguous, instead of committing to
        a coin flip.
        """
        obj = cls({}, max_suffix=max_suffix, key_feats=key_feats)
        counts: dict[str, Counter] = defaultdict(Counter)

        for form, lemma, upos, feats in pairs:
            if not form or not lemma:
                continue
            enc = _enc(derive_best_rule(form, lemma))
            sig = obj._sig(feats)
            low = form.casefold()
            for k in range(1, min(max_suffix, len(low)) + 1):
                suf = low[-k:]
                counts[obj._key(upos, sig, suf)][enc] += 1
                if sig:
                    counts[obj._key(upos, "", suf)][enc] += 1

        rules: dict[str, str] = {}
        for key, ctr in counts.items():
            enc, n = ctr.most_common(1)[0]
            if n < min_count:
                continue
            if min_purity and n / sum(ctr.values()) < min_purity:
                continue
            rules[key] = enc
        obj.rules = rules
        return obj

    def lemmatize(self, form: str, upos: str, feats: dict | None = None) -> str | None:
        """Longest-suffix match; None means no rule fired (caller falls back)."""
        if not form:
            return None
        low = form.casefold()
        sig = self._sig(feats or {})
        for k in range(min(self.max_suffix, len(low)), 0, -1):
            suf = low[-k:]
            for key in (self._key(upos, sig, suf), self._key(upos, "", suf)):
                enc = self.rules.get(key)
                if enc is None:
                    continue
                out = apply_rule(_dec(enc), form)
                if out:
                    return out
        return None

    def to_json(self, path: str | Path) -> None:
        Path(path).write_text(
            json.dumps(
                {"max_suffix": self.max_suffix,
                 "key_feats": list(self.key_feats),
                 "rules": self.rules},
                ensure_ascii=False,
            ),
            encoding="utf-8",
        )

    @classmethod
    def from_json(cls, path: str | Path) -> "SuffixLemmatizer":
        d = json.loads(Path(path).read_text(encoding="utf-8"))
        return cls(d["rules"], d.get("max_suffix", 8), tuple(d.get("key_feats", ())))


class OovLemmatizer:
    """Suffix table + vocabulary, packaging the OOV override rule.

    The rule, measured on RRT (+166 fixed / -15 broken, OOV lemma 89.83% ->
    93.25%):

        if the neural lemma is not a word the lexicon recognises,
        and a suffix rule fires, prefer the suffix rule.

    The model keeps the benefit of the doubt whenever it produces something
    real, and loses it when it produces `specialișt`, `fascit`, `suprareali` --
    the malformed outputs caused by edit scripts storing an ABSOLUTE prefix
    length that does not fit the word at hand.

    `vocab` deliberately holds surface forms AND lemmas. In practice they almost
    coincide (352,004 forms vs 352,235 total strings), because a lemma is itself
    a valid word form -- but the union is the correct set to test membership
    against.
    """

    def __init__(self, table: SuffixLemmatizer, vocab: set[str]):
        self.table = table
        self.vocab = vocab

    def resolve(
        self, form: str, upos: str, feats: dict, neural_lemma: str
    ) -> tuple[str, str]:
        """-> (lemma, source). `source` is "model" or "suffix"."""
        if neural_lemma and neural_lemma.casefold() in self.vocab:
            return neural_lemma, "model"
        out = self.table.lemmatize(form, upos, feats)
        if out and out != neural_lemma:
            return out, "suffix"
        return neural_lemma, "model"

    def save(self, path: str | Path) -> None:
        Path(path).write_text(
            json.dumps(
                {
                    "max_suffix": self.table.max_suffix,
                    "key_feats": list(self.table.key_feats),
                    "rules": self.table.rules,
                    "vocab": sorted(self.vocab),
                },
                ensure_ascii=False,
            ),
            encoding="utf-8",
        )

    @classmethod
    def load(cls, path: str | Path) -> "OovLemmatizer":
        d = json.loads(Path(path).read_text(encoding="utf-8"))
        table = SuffixLemmatizer(
            d["rules"], d.get("max_suffix", 8), tuple(d.get("key_feats", ()))
        )
        return cls(table, set(d["vocab"]))
