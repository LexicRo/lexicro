"""Composite (UPOS + UFeats) tag space.

The tagger predicts a single label per token: UPOS glued to a canonicalised
FEATS bundle. Encoding choice:

    NOUN|Case=Acc|Definite=Def|Gender=Fem|Number=Sing
    VERB|_
    PUNCT|_

The UPOS is everything before the first `|`; the remainder is the FEATS string
(already `|`-joined internally, `_` when empty). `split_tag` reverses it
unambiguously because UPOS values never contain `|`.

FEATS are sorted by feature name so identical bundles collapse to one label
regardless of source ordering. UD mandates alphabetical order already, but the
defensive sort is free and guards against non-conformant input.
"""

from __future__ import annotations

import json
from collections import Counter
from pathlib import Path
from typing import Iterable

from .data import Word


def canonical_feats(feats: dict, inventory: list[str] | None = None) -> str:
    """Render a FEATS dict as a canonical string.

    If `inventory` is given, only those features are kept — this is how you
    restrict the exposed morphology to a stable, tractable subset (Case, Number,
    Gender, Person, Tense, Mood, VerbForm, Definite, PronType, ...). Empty
    inventory (`None` or `[]`) keeps every feature observed.
    """
    if inventory:
        items = [(k, feats[k]) for k in inventory if k in feats]
    else:
        items = list(feats.items())
    if not items:
        return "_"
    return "|".join(f"{k}={v}" for k, v in sorted(items))


def composite_tag(upos: str, feats: dict, inventory: list[str] | None = None) -> str:
    return f"{upos}|{canonical_feats(feats, inventory)}"


def split_tag(tag: str) -> tuple[str, str]:
    """Inverse of `composite_tag`: returns (upos, feats_str)."""
    upos, _, feats = tag.partition("|")
    return upos, feats


def parse_feats_str(feats_str: str) -> dict:
    """Parse a canonical FEATS string back into a dict."""
    if feats_str in ("", "_"):
        return {}
    return dict(pair.split("=", 1) for pair in feats_str.split("|"))


class LabelSpace:
    """Bidirectional composite-tag <-> id mapping, plus frequency stats."""

    def __init__(self, tags: Iterable[str]):
        self.counts = Counter(tags)
        self.labels = sorted(self.counts)
        self.label2id = {t: i for i, t in enumerate(self.labels)}
        self.id2label = {i: t for t, i in self.label2id.items()}

    def __len__(self) -> int:
        return len(self.labels)

    @classmethod
    def from_sentences(
        cls, sentences: Iterable[list[Word]], inventory: list[str] | None = None
    ) -> "LabelSpace":
        tags = [
            composite_tag(w.upos, w.feats, inventory)
            for sent in sentences
            for w in sent
        ]
        return cls(tags)

    def feature_inventory(self) -> list[str]:
        """Distinct feature names appearing anywhere in the label space."""
        feats: set[str] = set()
        for tag in self.labels:
            _, fstr = split_tag(tag)
            feats.update(parse_feats_str(fstr))
        return sorted(feats)

    def most_common(self, n: int = 20) -> list[tuple[str, int]]:
        return self.counts.most_common(n)

    def to_json(self, path: str | Path) -> None:
        payload = {"labels": self.labels, "counts": dict(self.counts)}
        Path(path).write_text(json.dumps(payload, ensure_ascii=False, indent=2))

    @classmethod
    def from_json(cls, path: str | Path) -> "LabelSpace":
        payload = json.loads(Path(path).read_text())
        obj = cls.__new__(cls)
        obj.counts = Counter(payload.get("counts", {}))
        obj.labels = list(payload["labels"])
        obj.label2id = {t: i for i, t in enumerate(obj.labels)}
        obj.id2label = {i: t for t, i in obj.label2id.items()}
        return obj
