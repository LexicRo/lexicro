"""Lexicon layer — the hybrid seam.

Loads a MULTEXT-East word-form lexicon (`form <TAB> lemma <TAB> MSD`, one entry
per line) and bridges every MSD to UD, producing per-form candidates:

    form (casefolded) -> [(composite_tag, lemma), ...]

That single structure serves both halves of the hybrid:

* **Constrained tag decoding.** The candidate tags for a form are the only tags
  it can legally take, so the tag head's logits are masked to them. A constraint
  only ever removes options, so it is strictly beneficial and needs no retraining.

* **Exact lemma lookup.** Once the tag is decided, `(form, tag) -> lemma` is a
  dictionary read. This is what turns lemma from a prediction into a lexical
  fact -- and it is where the accuracy lives, because a lemma is not inferable
  from context the way morphology is. You either know the word or you don't.

Tokens absent from the lexicon fall through to the neural path unchanged. That
is the OOV route, and it stays honest: no guessing dressed up as lookup.

Casing: keys are casefolded (sentence-initial capitals must still match), while
lemmas are returned exactly as the lexicon stores them, so `Washingtonului` ->
`Washington` keeps its capital.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from pathlib import Path

from .bridge import msd_to_ud
from .labels import composite_tag


class Lexicon:
    def __init__(self, entries: dict[str, list[tuple[str, str]]]):
        # form_cf -> list of (composite_tag, lemma)
        self.entries = entries

    def __len__(self) -> int:
        return len(self.entries)

    @classmethod
    def from_wfl(
        cls,
        path: str | Path,
        inventory: list[str] | None = None,
    ) -> "Lexicon":
        """Load a MULTEXT-East word-form lexicon and bridge its MSDs to UD."""
        entries: dict[str, list[tuple[str, str]]] = defaultdict(list)
        skipped = 0
        with open(path, encoding="utf-8", errors="replace") as fh:
            for line in fh:
                parts = line.rstrip("\n").split("\t")
                if len(parts) < 3 or not (parts[0] and parts[1] and parts[2]):
                    skipped += 1
                    continue
                form, lemma, msd = parts[0], parts[1], parts[2]
                conv = msd_to_ud(msd)
                if conv.upos is None:
                    skipped += 1
                    continue
                tag = composite_tag(conv.upos, conv.feats, inventory)
                pair = (tag, lemma)
                bucket = entries[form.casefold()]
                if pair not in bucket:      # dedupe: many MSDs collapse to one UD tag
                    bucket.append(pair)
        obj = cls(dict(entries))
        obj.skipped = skipped
        return obj

    # ---- constrained decoding ------------------------------------------

    def candidate_tags(self, form: str) -> list[str]:
        return [t for t, _ in self.entries.get(form.casefold(), ())]

    def candidate_tag_ids(self, form: str, label2id: dict[str, int]) -> set[int]:
        """Tag ids allowed for this form. Empty set = unknown form (OOV path).

        A tag the model has never seen (absent from label2id) cannot be decoded,
        so it is dropped from the candidate set rather than silently widening it.
        """
        ids = {label2id[t] for t in self.candidate_tags(form) if t in label2id}
        return ids

    # ---- exact lemma lookup ---------------------------------------------

    def lemma_for(self, form: str, tag: str | None = None) -> str | None:
        """Lemma for (form, tag). None = not resolvable, use the neural path.

        Resolution order:
          1. exact (form, tag) match -- the normal case;
          2. the form is lemma-unambiguous (every entry agrees), so the tag does
             not matter and a wrong tag prediction cannot hurt us;
          3. otherwise ambiguous and the tag missed -- fall back to the most
             frequent lemma for the form rather than returning nothing, since a
             lexicon guess still beats an edit-script guess on a known word.
        """
        bucket = self.entries.get(form.casefold())
        if not bucket:
            return None

        if tag is not None:
            for t, lemma in bucket:
                if t == tag:
                    return lemma

        lemmas = {lemma for _, lemma in bucket}
        if len(lemmas) == 1:
            return next(iter(lemmas))

        return Counter(lemma for _, lemma in bucket).most_common(1)[0][0]

    def known(self, form: str) -> bool:
        return form.casefold() in self.entries

    def forms(self) -> set[str]:
        """Casefolded surface inventory -- use as `known_forms` in the scorer."""
        return set(self.entries)

    # ---- lemma-head training data ---------------------------------------

    def training_pairs(self) -> list[tuple[str, str, str]]:
        """(form, lemma, tag) triples for pretraining the OOV edit-script head.

        Type-level, not token-level: each form appears once regardless of corpus
        frequency. That is exactly the distribution the OOV path faces at serve
        time, so it is the right sample to learn from.
        """
        out: list[tuple[str, str, str]] = []
        for form_cf, bucket in self.entries.items():
            for tag, lemma in bucket:
                out.append((form_cf, lemma, tag))
        return out

    def stats(self) -> str:
        n_entries = sum(len(v) for v in self.entries.values())
        ambiguous = sum(
            1 for v in self.entries.values() if len({lemma for _, lemma in v}) > 1
        )
        return (
            f"forms: {len(self.entries)}  |  (tag, lemma) pairs: {n_entries}  |  "
            f"lemma-ambiguous forms: {ambiguous} ({ambiguous / max(len(self.entries), 1):.2%})"
        )
