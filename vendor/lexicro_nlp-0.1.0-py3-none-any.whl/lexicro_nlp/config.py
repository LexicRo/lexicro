"""Typed view over config.yaml. Scripts also accept explicit CLI paths, so the
config is a convenience for defaults rather than a hard dependency."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import yaml


@dataclass
class Treebank:
    name: str
    repo: str
    primary: bool = False


@dataclass
class Config:
    raw_dir: Path
    treebanks: list[Treebank]
    feature_inventory: list[str] = field(default_factory=list)
    lowercase_lemma: bool = False

    @classmethod
    def load(cls, path: str | Path = "config.yaml") -> "Config":
        data = yaml.safe_load(Path(path).read_text())
        d = data.get("data", {})
        labels = data.get("labels", {})
        return cls(
            raw_dir=Path(d.get("raw_dir", "data/raw")),
            treebanks=[Treebank(**tb) for tb in d.get("treebanks", [])],
            feature_inventory=labels.get("feature_inventory", []) or [],
            lowercase_lemma=labels.get("lowercase_lemma", False),
        )

    def treebank_dir(self, name: str) -> Path:
        return self.raw_dir / name
